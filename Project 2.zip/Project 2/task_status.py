class TaskStatus:
    FAIL = -1
    ONGOING = 0
    SUCCESS = 1